package mx.edu.wordart;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.*;

/** Editor de fuentes y efectos tipo WordArt, implementado con Swing y Java 2D. */
public final class EditorWordArt extends JFrame {
    private static final long serialVersionUID = 1L;
    private final JTextField texto = new JTextField("Fuentes Java 2D");
    private final JComboBox<String> fuente = new JComboBox<>(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
    private final JSpinner tamano = new JSpinner(new SpinnerNumberModel(96, 16, 160, 2));
    private final JCheckBox negrita = new JCheckBox("Negrita", true), cursiva = new JCheckBox("Cursiva");
    private final JCheckBox degradado = new JCheckBox("Relleno degradado", true), sombra = new JCheckBox("Activar sombra", true);
    private final JSlider contorno = new JSlider(0, 8, 2), perspectiva = new JSlider(-70, 70, 0);
    private final JSlider rotacion = new JSlider(-45,45,0), sombraX = new JSlider(-40,40,10), sombraY = new JSlider(-40,40,12);
    private final JSlider desenfoque = new JSlider(0,12,4), opacidad = new JSlider(0,100,45);
    private final BotonColor color1 = new BotonColor("Superior / principal", new Color(41,169,255));
    private final BotonColor color2 = new BotonColor("Inferior", new Color(32,63,188));
    private final BotonColor colorContorno = new BotonColor("Color de contorno", new Color(18,38,90));
    private final BotonColor colorSombra = new BotonColor("Color de sombra", new Color(25,35,55));
    private final JComboBox<String> fondo = new JComboBox<>(new String[]{"Blanco", "Oscuro", "Transparente"});
    private final Vista vista = new Vista();
    private final JLabel estado = new JLabel("Preparando vista previa...");
    private final JButton exportar = new JButton("Guardar PNG");
    private final Timer espera = new Timer(140, e -> actualizar());
    private long revision;
    private boolean cargando;

    public EditorWordArt() {
        super("Fuentes Java 2D · Editor WordArt");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(940,680));
        JPanel raiz = new JPanel(new BorderLayout(16,16));
        raiz.setBorder(new EmptyBorder(18,18,12,18));
        raiz.setBackground(new Color(239,242,248)); setContentPane(raiz);
        JPanel encabezado = new JPanel(new BorderLayout(20,0)); encabezado.setOpaque(false);
        JLabel titulo = new JLabel("Fuentes Java 2D"); titulo.setFont(new Font("SansSerif",Font.BOLD,25));
        encabezado.add(titulo,BorderLayout.WEST);
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0)); acciones.setOpaque(false);
        JButton restablecer = new JButton("Restablecer"); acciones.add(restablecer); acciones.add(exportar);
        encabezado.add(acciones,BorderLayout.EAST); raiz.add(encabezado,BorderLayout.NORTH);

        JPanel opciones = new JPanel(); opciones.setLayout(new BoxLayout(opciones,BoxLayout.Y_AXIS));
        opciones.setBorder(new EmptyBorder(2,2,12,10));
        JPanel letras = seccion("TEXTO Y FUENTE");
        ((AbstractDocument)texto.getDocument()).setDocumentFilter(new LimiteTexto());
        letras.add(new JLabel("Texto (máximo 100 caracteres)")); letras.add(texto);
        letras.add(new JLabel("Familia tipográfica")); letras.add(fuente);
        letras.add(fila(new JLabel("Tamaño"),tamano)); letras.add(fila(negrita,cursiva)); opciones.add(letras);
        JPanel relleno = seccion("RELLENO Y CONTORNO");
        relleno.add(degradado); relleno.add(fila(color1,color2));
        relleno.add(control("Grosor del contorno", contorno, " px")); relleno.add(colorContorno); opciones.add(relleno);
        JPanel forma = seccion("PERSPECTIVA Y ROTACIÓN");
        forma.add(control("Perspectiva",perspectiva," %"));
        JLabel ayuda = new JLabel("− estrecha la base · + estrecha la parte superior"); ayuda.setFont(new Font("SansSerif",Font.PLAIN,10)); forma.add(ayuda);
        forma.add(control("Rotación",rotacion,"°")); opciones.add(forma);
        JPanel sombras = seccion("SOMBRA DEL TEXTO");
        sombras.add(sombra); sombras.add(control("Desplazamiento X",sombraX," px"));
        sombras.add(control("Desplazamiento Y",sombraY," px"));
        sombras.add(control("Suavidad",desenfoque," px")); sombras.add(control("Opacidad",opacidad," %"));
        sombras.add(colorSombra); opciones.add(sombras);
        JScrollPane scroll = new JScrollPane(opciones); scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(18); scroll.setPreferredSize(new Dimension(355,560));
        raiz.add(scroll,BorderLayout.WEST);

        JPanel derecha = new JPanel(new BorderLayout(0,12)); derecha.setOpaque(false);
        JPanel barra = new JPanel(new BorderLayout()); barra.setOpaque(false);
        barra.add(new JLabel("VISTA PREVIA"),BorderLayout.WEST);
        barra.add(fila(new JLabel("Fondo"),fondo),BorderLayout.EAST); derecha.add(barra,BorderLayout.NORTH);
        vista.setPreferredSize(new Dimension(680,510)); derecha.add(vista,BorderLayout.CENTER);
        JPanel estilos = new JPanel(new GridLayout(1,4,8,0)); estilos.setOpaque(false);
        String[] nombres = {"Azul clásico", "Dorado", "Perspectiva", "Neón"};
        for (int i=0;i<nombres.length;i++) {
            final int indice=i; JButton b=new JButton(nombres[i]); b.addActionListener(e -> preset(indice)); estilos.add(b);
        }
        derecha.add(estilos,BorderLayout.SOUTH); raiz.add(derecha,BorderLayout.CENTER);
        estado.setBorder(new EmptyBorder(4,0,0,0)); raiz.add(estado,BorderLayout.SOUTH);
        espera.setRepeats(false);
        texto.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { solicitar(); }
            public void removeUpdate(DocumentEvent e) { solicitar(); }
            public void changedUpdate(DocumentEvent e) { solicitar(); }
        });
        fuente.addActionListener(e -> solicitar()); tamano.addChangeListener(e -> solicitar());
        for (JCheckBox c : new JCheckBox[]{negrita,cursiva,degradado,sombra}) c.addActionListener(e -> solicitar());
        for (JSlider s : new JSlider[]{contorno,perspectiva,rotacion,sombraX,sombraY,desenfoque,opacidad}) s.addChangeListener(e -> solicitar());
        fondo.addActionListener(e -> { vista.repaint(); actualizarEstado(); });
        restablecer.addActionListener(e -> { cargando=true; texto.setText("Fuentes Java 2D"); tamano.setValue(96); fondo.setSelectedIndex(0); cargando=false; preset(0); });
        exportar.addActionListener(e -> guardar());
        fuente.setSelectedItem("SansSerif"); preset(0);
        pack(); setLocationRelativeTo(null);
    }
    private void solicitar() {
        if (!cargando) { revision++; espera.restart(); }
    }
    private Estilo estilo() {
        return new Estilo(texto.getText(),(String)fuente.getSelectedItem(),((Number)tamano.getValue()).intValue(),
            negrita.isSelected(),cursiva.isSelected(),degradado.isSelected(),color1.color,color2.color,
            contorno.getValue(),colorContorno.color,perspectiva.getValue(),rotacion.getValue(),sombra.isSelected(),
            sombraX.getValue(),sombraY.getValue(),desenfoque.getValue(),opacidad.getValue(),colorSombra.color);
    }
    private void actualizar() {
        Estilo e=estilo(); long solicitud=revision;
        new SwingWorker<BufferedImage,Void>() {
            protected BufferedImage doInBackground() { return MotorTexto.renderizar(e); }
            protected void done() {
                if(solicitud!=revision) return;
                try { vista.imagen=get(); vista.repaint(); actualizarEstado(); }
                catch(Exception ex) { estado.setText("No se pudo dibujar el texto: "+ex.getMessage()); }
            }
        }.execute();
    }
    private void actualizarEstado() {
        if (texto.getText().isBlank()) estado.setText("Escribe un texto para comenzar.");
        else estado.setText("Vista ajustada al panel · El PNG conserva la resolución del diseño · Fondo: "+fondo.getSelectedItem());
    }
    private void preset(int numero) {
        cargando=true;
        fuente.setSelectedItem("SansSerif"); negrita.setSelected(true); cursiva.setSelected(false); degradado.setSelected(true);
        contorno.setValue(2); perspectiva.setValue(0); rotacion.setValue(0); sombra.setSelected(true);
        sombraX.setValue(10); sombraY.setValue(12); desenfoque.setValue(4); opacidad.setValue(45);
        colorSombra.poner(new Color(25,35,55));
        color1.poner(new Color(41,169,255)); color2.poner(new Color(32,63,188)); colorContorno.poner(new Color(18,38,90));
        switch(numero) {
            case 1 -> { fuente.setSelectedItem("Serif"); color1.poner(new Color(255,236,126)); color2.poner(new Color(197,110,15)); colorContorno.poner(new Color(98,56,12)); }
            case 2 -> { perspectiva.setValue(55); rotacion.setValue(-8); cursiva.setSelected(true); color1.poner(new Color(255,184,68)); color2.poner(new Color(224,63,76)); colorContorno.poner(new Color(116,30,54)); }
            case 3 -> { color1.poner(new Color(160,248,255)); color2.poner(new Color(30,208,237)); colorContorno.poner(new Color(23,155,193)); colorSombra.poner(new Color(0,226,255)); sombraX.setValue(0); sombraY.setValue(0); desenfoque.setValue(12); opacidad.setValue(100); fondo.setSelectedIndex(1); }
            default -> { }
        }
        cargando=false; solicitar();
    }
    private void guardar() {
        if(texto.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Escribe un texto antes de guardar."); return; }
        JFileChooser chooser=new JFileChooser(); chooser.setDialogTitle("Guardar texto como PNG");
        chooser.setFileFilter(new FileNameExtensionFilter("Imagen PNG", "png")); chooser.setSelectedFile(new File("WordArt.png"));
        if(chooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION) return;
        File elegido=chooser.getSelectedFile();
        if(!elegido.getName().toLowerCase(Locale.ROOT).endsWith(".png")) elegido=new File(elegido.getParentFile(),elegido.getName()+".png");
        if(elegido.exists() && JOptionPane.showConfirmDialog(this,"El archivo existe. ¿Quieres reemplazarlo?","Confirmar",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION) return;
        final File destino=elegido; Estilo opciones=estilo(); int fondoActual=fondo.getSelectedIndex(); exportar.setEnabled(false);
        new SwingWorker<Void,Void>() {
            protected Void doInBackground() throws Exception {
                BufferedImage im=MotorTexto.renderizar(opciones);
                if(fondoActual!=2) {
                    BufferedImage compuesta=new BufferedImage(im.getWidth(),im.getHeight(),BufferedImage.TYPE_INT_RGB);
                    Graphics2D g=compuesta.createGraphics(); g.setColor(fondoActual==0?Color.WHITE:new Color(24,29,42));
                    g.fillRect(0,0,im.getWidth(),im.getHeight()); g.drawImage(im,0,0,null); g.dispose(); im=compuesta;
                }
                if(!ImageIO.write(im,"png",destino)) throw new java.io.IOException("No hay un codificador PNG disponible.");
                return null;
            }
            protected void done() {
                exportar.setEnabled(true);
                try { get(); estado.setText("PNG guardado: "+destino.getAbsolutePath()); }
                catch(Exception ex) { JOptionPane.showMessageDialog(EditorWordArt.this,"No se pudo guardar: "+ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE); }
            }
        }.execute();
    }
    private static JPanel seccion(String titulo) {
        JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createCompoundBorder(new TitledBorder(titulo),new EmptyBorder(6,8,8,8)));
        p.setAlignmentX(Component.LEFT_ALIGNMENT); return p;
    }
    private static JPanel fila(Component... componentes) {
        JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT,5,3)); p.setOpaque(false);
        for(Component c:componentes) p.add(c); return p;
    }
    private static JPanel control(String nombre,JSlider slider,String unidad) {
        JPanel p=new JPanel(new BorderLayout()); JLabel l=new JLabel(nombre+": "+slider.getValue()+unidad);
        slider.addChangeListener(e -> l.setText(nombre+": "+slider.getValue()+unidad));
        p.add(l,BorderLayout.NORTH); p.add(slider,BorderLayout.CENTER); return p;
    }
    private final class BotonColor extends JButton {
        private static final long serialVersionUID=1L;
        private Color color;
        BotonColor(String nombre,Color valor) {
            super(nombre); poner(valor); setMargin(new Insets(5,7,5,7));
            addActionListener(e -> { Color c=JColorChooser.showDialog(EditorWordArt.this,nombre,color); if(c!=null) { poner(c); solicitar(); } });
        }
        void poner(Color c) {
            color=c; setIcon(new Icon() {
                public int getIconWidth(){return 14;} public int getIconHeight(){return 14;}
                public void paintIcon(Component comp,Graphics g,int x,int y){g.setColor(c);g.fillRect(x,y,13,13);g.setColor(Color.GRAY);g.drawRect(x,y,13,13);}
            });
        }
    }
    private final class Vista extends JPanel {
        private static final long serialVersionUID=1L;
        private BufferedImage imagen;
        @Override protected void paintComponent(Graphics original) {
            super.paintComponent(original); Graphics2D g=(Graphics2D)original.create(); MotorTexto.calidad(g);
            int modo=fondo.getSelectedIndex();
            g.setColor(modo==1?new Color(24,29,42):Color.WHITE); g.fillRect(0,0,getWidth(),getHeight());
            if(modo==2) {
                g.setColor(new Color(229,232,237));
                for(int y=0;y<getHeight();y+=16) for(int x=0;x<getWidth();x+=16) if((x/16+y/16)%2==0)g.fillRect(x,y,16,16);
            }
            if(imagen!=null && !texto.getText().isBlank()) {
                double s=Math.min(1.5,Math.min((getWidth()-48.0)/imagen.getWidth(),(getHeight()-48.0)/imagen.getHeight()));
                int w=Math.max(1,(int)(imagen.getWidth()*s)),h=Math.max(1,(int)(imagen.getHeight()*s));
                g.drawImage(imagen,(getWidth()-w)/2,(getHeight()-h)/2,w,h,null);
            } else {
                g.setColor(modo==1?Color.LIGHT_GRAY:Color.GRAY);g.drawString("Escribe tu texto en el panel izquierdo",30,45);
            }
            g.dispose();
        }
    }
    private static final class LimiteTexto extends DocumentFilter {
        @Override public void insertString(FilterBypass fb,int off,String str,AttributeSet a) throws BadLocationException {replace(fb,off,0,str,a);}
        @Override public void replace(FilterBypass fb,int off,int len,String str,AttributeSet a) throws BadLocationException {
            String valor=str==null?"":str.replace('\n',' ').replace('\r',' ').replace('\t',' ');
            String actual=fb.getDocument().getText(0,fb.getDocument().getLength());
            String nuevo=actual.substring(0,off)+valor+actual.substring(off+len);
            if(nuevo.codePointCount(0,nuevo.length())<=100) super.replace(fb,off,len,valor,a);
            else Toolkit.getDefaultToolkit().beep();
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch(Exception ignored) { }
            new EditorWordArt().setVisible(true);
        });
    }
}
