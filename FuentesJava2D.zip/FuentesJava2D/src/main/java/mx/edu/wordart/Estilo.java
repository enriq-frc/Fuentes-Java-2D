package mx.edu.wordart;

import java.awt.Color;

/** Opciones inmutables: un mismo estado produce la vista y la exportación. */
public record Estilo(String texto, String fuente, int tamano, boolean negrita,
        boolean cursiva, boolean degradado, Color color1, Color color2,
        int contorno, Color colorContorno, int perspectiva, int rotacion,
        boolean sombra, int sombraX, int sombraY, int desenfoque,
        int opacidad, Color colorSombra) { }
