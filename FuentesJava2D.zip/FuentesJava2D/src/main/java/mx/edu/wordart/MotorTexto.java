package mx.edu.wordart;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.geom.*;
import java.awt.image.*;

/** Render de texto con Java 2D, proyección, rotación y sombra con desenfoque. */
public final class MotorTexto {
    private MotorTexto() { }
    public static BufferedImage renderizar(Estilo e) {
        if (e.texto().isBlank()) return new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        int estilo = (e.negrita() ? Font.BOLD : 0) | (e.cursiva() ? Font.ITALIC : 0);
        Font f = new Font(e.fuente(), estilo, e.tamano());
        TextLayout layout = new TextLayout(e.texto(), f, new FontRenderContext(null, true, true));
        Shape letras = layout.getOutline(null);
        Rectangle2D b = letras.getBounds2D();
        // Se limita la resolución de trabajo para mantener fluida la interfaz.
        double escala = Math.min(1, 1600 / Math.max(1, b.getWidth()));
        int pad = e.contorno() + 8;
        int w = Math.max(1, (int) Math.ceil(b.getWidth() * escala) + pad * 2);
        int h = Math.max(1, (int) Math.ceil(b.getHeight() * escala) + pad * 2);
        BufferedImage base = nueva(w, h);
        Graphics2D g = base.createGraphics(); calidad(g);
        g.translate(pad, pad); g.scale(escala, escala); g.translate(-b.getX(), -b.getY());
        if (e.degradado()) {
            g.setPaint(new GradientPaint(0, (float) b.getMinY(), e.color1(),
                0, (float) Math.max(b.getMinY() + 1, b.getMaxY()), e.color2()));
        } else g.setColor(e.color1());
        g.fill(letras);
        if (e.contorno() > 0) {
            g.setColor(e.colorContorno());
            g.setStroke(new BasicStroke(e.contorno(), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(letras);
        }
        g.dispose();
        BufferedImage proyectada = perspectiva(base, e.perspectiva());
        BufferedImage girada = girar(proyectada, e.rotacion());
        if (!e.sombra()) return girada;
        int margen = Math.max(Math.abs(e.sombraX()), Math.abs(e.sombraY())) + e.desenfoque() * 2 + 8;
        BufferedImage sombra = nueva(girada.getWidth() + 2 * margen, girada.getHeight() + 2 * margen);
        Graphics2D sg = sombra.createGraphics();
        sg.drawImage(girada, margen + e.sombraX(), margen + e.sombraY(), null);
        sg.setComposite(AlphaComposite.SrcIn);
        sg.setColor(new Color(e.colorSombra().getRed(), e.colorSombra().getGreen(),
            e.colorSombra().getBlue(), Math.round(255 * e.opacidad() / 100f)));
        sg.fillRect(0, 0, sombra.getWidth(), sombra.getHeight()); sg.dispose();
        sombra = desenfocar(sombra, e.desenfoque());
        Graphics2D resultado = sombra.createGraphics(); calidad(resultado);
        resultado.drawImage(girada, margen, margen, null); resultado.dispose();
        return sombra;
    }
    /** Proyección trapezoidal inversa. La división racional también comprime Y;
     * no se trata únicamente de inclinar el texto con una transformación afín. */
    static BufferedImage perspectiva(BufferedImage origen, int valor) {
        if (valor == 0) return origen;
        int w = origen.getWidth(), h = origen.getHeight();
        BufferedImage salida = nueva(w, h);
        double p = Math.max(-.75, Math.min(.75, valor / 100.0));
        double arriba = p > 0 ? 1 - p : 1;
        double abajo = p < 0 ? 1 + p : 1;
        for (int y = 0; y < h; y++) {
            double t = (y + .5) / h;
            double ancho = arriba + (abajo - arriba) * t;
            double v = arriba * t / (abajo + (arriba - abajo) * t);
            for (int x = 0; x < w; x++) {
                double u = .5 + ((x + .5) / w - .5) / ancho;
                if (u >= 0 && u <= 1) salida.setRGB(x, y, muestrear(origen, u * w - .5, v * h - .5));
            }
        }
        return salida;
    }
    // Interpolación bilineal con color premultiplicado para evitar halos oscuros.
    private static int muestrear(BufferedImage im, double x, double y) {
        x = Math.max(0, Math.min(im.getWidth() - 1, x));
        y = Math.max(0, Math.min(im.getHeight() - 1, y));
        int x0 = (int) x, y0 = (int) y;
        int x1 = Math.min(x0 + 1, im.getWidth() - 1), y1 = Math.min(y0 + 1, im.getHeight() - 1);
        double fx = x - x0, fy = y - y0;
        int[] pix = {im.getRGB(x0,y0), im.getRGB(x1,y0), im.getRGB(x0,y1), im.getRGB(x1,y1)};
        double[] pesos = {(1-fx)*(1-fy), fx*(1-fy), (1-fx)*fy, fx*fy};
        double a = 0, r = 0, g = 0, b = 0;
        for (int i = 0; i < 4; i++) {
            double alpha = ((pix[i] >>> 24) & 255) * pesos[i];
            a += alpha; r += ((pix[i] >>> 16) & 255) * alpha;
            g += ((pix[i] >>> 8) & 255) * alpha; b += (pix[i] & 255) * alpha;
        }
        if (a < .5) return 0;
        return ((int)Math.round(a) << 24) | ((int)Math.round(r/a) << 16)
            | ((int)Math.round(g/a) << 8) | (int)Math.round(b/a);
    }
    private static BufferedImage girar(BufferedImage im, int grados) {
        if (grados == 0) return im;
        AffineTransform rotacion = AffineTransform.getRotateInstance(Math.toRadians(grados));
        Rectangle2D limites = rotacion.createTransformedShape(new Rectangle(0,0,im.getWidth(),im.getHeight())).getBounds2D();
        BufferedImage salida = nueva((int)Math.ceil(limites.getWidth()) + 4, (int)Math.ceil(limites.getHeight()) + 4);
        Graphics2D g = salida.createGraphics(); calidad(g);
        g.translate(2 - limites.getX(), 2 - limites.getY()); g.transform(rotacion);
        g.drawImage(im, 0, 0, null); g.dispose(); return salida;
    }
    private static BufferedImage desenfocar(BufferedImage im, int radio) {
        if (radio <= 0) return im;
        int n = 2 * radio + 1; float[] kernel = new float[n];
        double sigma = Math.max(1, radio / 2.0), suma = 0;
        for (int i = 0; i < n; i++) { double d = i - radio; kernel[i] = (float)Math.exp(-d*d/(2*sigma*sigma)); suma += kernel[i]; }
        for (int i = 0; i < n; i++) kernel[i] /= suma;
        BufferedImage tmp = new ConvolveOp(new Kernel(n,1,kernel), ConvolveOp.EDGE_NO_OP, null).filter(im, null);
        return new ConvolveOp(new Kernel(1,n,kernel), ConvolveOp.EDGE_NO_OP, null).filter(tmp, null);
    }
    private static BufferedImage nueva(int w, int h) { return new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB); }
    static void calidad(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    }
}
